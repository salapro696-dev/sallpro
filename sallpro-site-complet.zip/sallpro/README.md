# SallPro

- `/` : site
- `/app/` : application
- `/admin/` : espace admin

Site statique, déployé sur Cloudflare Pages. Aucune commande de build.
